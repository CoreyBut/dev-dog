# dev-dog

🦭Cumbie CIS 376 Web Dev Spring '25 Midterm Dev Exam

### Resources

- Internet, past projects, and all
- no LIVE help, chat, email, or otherwise (I'm watching 👀)
- stuck/confused? Raise your hand & I'll walk over to you
- DO NOT upload your work to GitHub or anywhere else

### Instructions

1. download & unzip to work locally
2. start with the `index` and look for todo and dog emoji 🐶 (tip: TODO extension)
3. do not delete the "TODO:🐶#" comments. You may add your own remarks, just make it clear to me they are yours, in a new comment with your initials or own emoji.
4. Last 2 todo's:

- TODO: 🐶19. Add in your authorship comments in THIS README document. (It's a joint authorship, right?). Include the date and that this is for your CIS 376 mid term exam, and don't forget to include at least ONE attribution to other code sources.
- TODO: 🐶20. Add in an image with a screenshot of you with exactly 4782 points

5. test it all locally and, when ready,
6. zip and submit to Canvas
